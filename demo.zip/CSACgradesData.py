gradesDir = r'C:\Users\YourUserName\Downloads\Demo\Grades4Gradebook'
codingBatDir = ''   # data written by https://github.com/rainerpm/CodingBatScraper

# maps the class name from the classPeriodNames list in CSACcustomize.py to the class name used in ASSIGNMENTS dictionary below
classPeriods = { 'P1'   : 'AP CS',
                 'P4'   : 'Fundamentals',
                 'P5'   : 'Fundamentals',
               }

latePenaltyPercentageDefault = 0.70   # programs flagged as late are worth this percentage of the points

# ASSIGNMENTS dictionary
# key = Grade Book name
# value = (class, assignment group, gradingTuple)
#    gradingTuple = (pointsPossible,assignmentTuple1,assignmentTuple2,...)
#       * points possible is a integer number for the total points of assignment group OR
#         a tuple representing the points for assignments where grading is based on how many assignments in the assignment group are completed: 1st tuple element is points for 0 completed, 2nd is for 1 completed, 3rd is for 2 completed, ...
#       * each assignmentTuple = assignmentName, percentOfAssignment (integer or float - see note about optional assignmetns below),[optional: percentDeductionForIncorrectSubmission]
#       * example 1  (10,('calculator',100))  a 10pt assignment called calculator
#       * example 2  (20,('pgm1a',80),('pgm1b',15),('pgm1c',5))    pgm1a correct is 80% (i.e. 16pts), pgm1a & pgm1b correct is 95%=80%+15%, pgm1a,pgm1b,pgm1c correct is 100%=80%+15%+5%
#       * example 3  (20,('pgm1a',80,10),('pgm1b',15),('pgm1c',5)) same as above except that 2pts (10% of 20pts) are deducted for every incorrect submission of pgm1a    
#       * example 4  ((0,7.5,9,10.5,12,13.5,15),('pgm1a',),('pgm1b',),('pgm1c',),('pgm1d',),('pgm1e',),('pgm1f',))   6 total programs 0 correct = 0 pts,  1 correct = 7.5pts, 2=9pts, 3=10.5pts, ...
#                                                       NOTE: A tuple with a single element requires a , after the element
# A note about optional assigments
#   Assignments can be optional and their points are counted if a later part of the assignment is correct.
#   Optional assignments are indicated by adding the string '(opt)' to the front of the assignment name.
ASSIGNMENTS = {
########################################## PYTHON ######################################################    
'python'                  : ('Fundamentals','pythonAssignments',(10,('encrypt',100))),
#'Ciphers'                  : ('Fundamentals','PYTHON_03_SecondAssignments',(15,('caesar',90),('vigenere',10))),     
#'Lets get loopy'           : ('Fundamentals','PYTHON_02_Lets_Get_Loopy',((0,9,15,21,24,25.5,27,27.9,28.8,29.4,30,31.5,33,34.5),('01sal',),('02fib',),('03days',),('04agtb',),('05pi',),('06collatz',),('07power',),('08triplet',),('09polter',),('10champ',),('11area',),('12flip',),('13coin',))),
#'For loops'                : ('Fundamentals','PYTHON_01_FirstAssignments',(4,('for',100,12.5))),  # deduct 1/2 point (12.5%) for every incorrect submission
########################################### JAVA #######################################################    
'1st 6 Weeks'               : ('AP CS','first6weeksAssignments',(10,('GCD',100))),
#'Hello World'                : ('AP','JAVA_00_FirstAssignments',(3,('Hello',100))),
#'User Input'                 : ('AP','JAVA_00_FirstAssignments',(5,('UserInput',100,10.0))),   # -1/2 point (10%  of 5 points) for every incorrect submission
#'Methods Part 1'             : ('AP','JAVA_01_WritingAndCallingMethods',(10,('Rounding',50),('GallonsWasted',20),('BeanCount',20),('RandomStatement',10))),
#'Methods Part 2'             : ('AP','JAVA_01_WritingAndCallingMethods',(10,('Tasking',70),('Invocations',30))),
#'Book & StudentId'           : ('AP','JAVA_02_Objects1',(15,('Book',80),('StudentId',20))),
}
