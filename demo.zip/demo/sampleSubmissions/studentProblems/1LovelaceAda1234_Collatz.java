// If you are doing this correctly your code should not be more then 120 lines
// (including blank lines separating the methods).
public class Collatz {
	// instance variables (aka members, fields)
	private int startNum;  

   // default constructor
	public Collatz()
	{
		startNum = 0;
	}
   
   // initalization constructor
   public Collatz(int start) {
      startNum = start;
   }
   
   // Add a method called steps() that returns the number of steps 
   // that are required for the starting number to reach 1.
   public int steps() {
      int num = startNum;
      int steps = 1;
      while (num != 1) {
         steps += 1;
         if (num % 2 == 0) {
            num = num / 2;
         }
         else {
            num = num * 3 + 1;
         }
      }
      return steps;
   }
   
   // Add a method called sequence() that returns an array of the sequence of 
   // numbers from the starting number to 1. Use your steps() function to 
   // determine how the size of your array.
   public int[] sequence() {
      int collatzSeq[] = new int[steps()];
      int count = 0;
      collatzSeq[0] = startNum;
      int num = startNum;
      while (num != 1) {
         if (num % 2 == 0) {
            num = num / 2;
         }
         else {
            num = num * 3 + 1;
         }
         collatzSeq[++count] = num;
      } 
      return collatzSeq;   
   }
   
   // Add a method called maxValue() that returns the maximum value in the sequence.
   // Iterate through the values returned by a call to sequence().
   public int maxValue() {
      int max = Integer.MIN_VALUE;
      for (int x : sequence()) {
         if (x > max) {
            max = x;
         }
      } 
      return max;  
   }

   // A method called minOddValue() that returns the minimum value of all the odd numbers, 
   // except for 1, in the sequence. Iterate through the values returned by a call to sequence().
   public int minOddValue() {
      int min = Integer.MAX_VALUE;
      for (int x : sequence()) {
         if ((x != 1) && (x < min) && (x % 2 == 1)) {
            min = x;
         }
      } 
      return min;  
   }

   // Add a method called oddValues() that returns an array of all the odd numbers in the sequence. 
   // Iterate through the values returned by a call to sequence().  
   public int[] oddValues() {
      int odds = 0;
      for (int x : sequence()) {
         odds += x % 2;   // avoided using an if statement here
      }
      int oddSeq[] = new int[odds]; 
      int idx = 0; 
      for (int x : sequence()) {
         if (x % 2 == 1) {
           oddSeq[idx++] = x;
         }
      }
      return oddSeq;
   }
      
   // Add a method called sumValues() that returns the sum of all the values in the sequence.
   // Iterate through the values returned by a call to sequence().
   public int sumValues() {
      int sum = 0;
      for (int x : sequence()) {
         sum += x;
      } 
      return sum;  
   }
   
   // Add a toString() method that returns ...    Starting number # takes # steps
   public String toString() {
      return "Starting Number " + startNum + " takes " + steps() + " steps"; 
   }
   
}

