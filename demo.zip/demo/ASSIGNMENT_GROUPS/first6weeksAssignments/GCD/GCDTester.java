import java.util.Scanner;

public class GCDTester
{
	//main method
	public static void main(String[] args)
	{
   
      // Testing modifier & accessor methods for numerator & denominator
      System.out.println("Testing 24/36");
		GCD myGCD = new GCD();
      myGCD.setNumerator(24);
      myGCD.setDenominator(36);
		System.out.println("  The GCD is: " + myGCD);
      System.out.println("  The fraction in lowest terms is " + myGCD.numeratorSimplified() + "/" + myGCD.denominatorSimplified());      
	
      // Testing 192/270
      System.out.println("Testing 192/270");
		myGCD = new GCD(192,270);
		System.out.println("  The GCD is: " + myGCD);
      System.out.println("  The fraction in lowest terms is " + myGCD.numeratorSimplified() + "/" + myGCD.denominatorSimplified());

      // Testing 270/192
      System.out.println("Testing 270/192");
		myGCD = new GCD(270,192);
		System.out.println("  The GCD is: " + myGCD);
      System.out.println("  The fraction in lowest terms is " + myGCD.numeratorSimplified() + "/" + myGCD.denominatorSimplified());

      // Testing 1/2
      System.out.println("Testing 1/2");
		myGCD = new GCD(1,2);
		System.out.println("  The GCD is: " + myGCD);
      System.out.println("  The fraction in lowest terms is " + myGCD.numeratorSimplified() + "/" + myGCD.denominatorSimplified());		
	}
}