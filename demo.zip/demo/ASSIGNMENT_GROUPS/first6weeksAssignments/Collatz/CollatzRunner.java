import java.util.Scanner;
import java.util.Arrays;

public class CollatzRunner {

  public static void main(String[] args) {
     // Read in starting number
     Scanner scan = new Scanner(System.in);
     System.out.print("Starting Number ");
     int startAt = scan.nextInt();
     
     // create collatz object
     Collatz collatz1 = new Collatz(startAt);
     
     // print out collatz object
     System.out.println(collatz1);
     System.out.println("Number of steps " + collatz1.steps());
     System.out.println("Maximum value " + collatz1.maxValue());
     System.out.println("Minimum odd value " + collatz1.minOddValue());     
     System.out.println("Odd values " + Arrays.toString(collatz1.oddValues()));     
     System.out.println("Sum of all values " + collatz1.sumValues());
     int[] firstSeq = collatz1.sequence();
     for (int i=0; i < firstSeq.length; i++) {
         System.out.println("step " + (i+1) + " " + firstSeq[i]);
         // System.out.printf("step %-3d %4d\n",i+1,firstSeq[i]);
     } 
          
  }
}