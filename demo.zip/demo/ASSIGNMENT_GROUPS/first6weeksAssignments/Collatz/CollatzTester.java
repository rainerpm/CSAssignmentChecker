import java.lang.reflect.*; 
import java.util.*; 

public class CollatzTester {
   public static void main(String[] args) {
   
     // *** Test the structure of the program ***
     // Set expectedInstanceVars, expectedMethods, and reflectedClass variables    
     ArrayList<String> expectedInstanceVars = new ArrayList<String>(
              Arrays.asList("startNum"));
     ArrayList<String> expectedMethods = new ArrayList<String>(
              Arrays.asList("maxValue",
                            "minOddValue",
                            "oddValues",
                            "sequence",
                            "steps",
                            "sumValues",
                            "toString"));  
     // Class that we are testing using reflection
     Collatz collatz = new Collatz();
     Class reflectedClass = collatz.getClass();
     // check the instance variables (make sure to put correct class name before .class below)
     checkInstanceVariables(expectedInstanceVars,reflectedClass);
     // check the instance variables (make sure to put correct class name before .class below)
     checkConstructors(reflectedClass);
     // check the methods (make sure to put correct class name before .class below)
     checkMethods(expectedMethods,reflectedClass);     

     // *** Test the operation of the program ***          
      System.out.println("\nTesting program operation");        
      System.out.println("\n  Testing Methods");        
      Collatz collatzObj = new Collatz(10);
      System.out.println("    steps(10) = " + collatzObj.steps());
  
      collatzObj = new Collatz(11);
      System.out.println("    maxValue() for Collatz(11) = " + collatzObj.maxValue());
      
      collatzObj = new Collatz(27);
      System.out.println("    minOddValue() for Collatz(27) = " + collatzObj.minOddValue()); 
      
      collatzObj = new Collatz(12);
      System.out.println("    oddValues() for Collatz(12) = " + Arrays.toString(collatzObj.oddValues()));     

      collatzObj = new Collatz(27);
      System.out.println("    sumValues() for Collatz(27) = " + collatzObj.sumValues());

      System.out.println("\n  Testing Collatz Objects");        
      collatzObj = new Collatz(5);
      System.out.println("    Collatz(5) = " + collatzObj);
      
      collatzObj = new Collatz(27);
      System.out.println("    Collatz(27) = " + collatzObj);      
 
   }
   
   // reflection methods 
   public static void checkInstanceVariables(ArrayList<String> expectedInstanceVars, Class cls) {
       ArrayList<String> output = new ArrayList<String>();
       System.out.println("Checking instance variables");
       Field[] instanceVars = cls.getDeclaredFields();
       for (Field instanceVar : instanceVars) {
         if (expectedInstanceVars.contains(instanceVar.getName())) {
           output.add(String.format("  %-20s %s ",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
           expectedInstanceVars.remove(instanceVar.getName());
         } else {
           output.add(String.format("  %-20s %s *** unexpected instance variable ***",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
         }
       }
       for (String expectedInstanceVar : expectedInstanceVars) {
          output.add(String.format("  %-20s *** missing instance variable ***",expectedInstanceVar));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("class java.lang.",""));
   }
    
   public static void checkConstructors(Class cls) {
       ArrayList<String> output = new ArrayList<String>();
       System.out.println("\nChecking constructors");
       Constructor[] constructors = cls.getConstructors();
       for (Constructor constructor : constructors) {
          output.add(String.format("  %-20s %s ",constructor.toGenericString(), Arrays.toString(constructor.getParameters())));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("java.lang.",""));
   }
   
   public static void checkMethods(ArrayList<String> expectedMethods, Class cls) {
       ArrayList<String> output = new ArrayList<String>();
       System.out.println("\nChecking methods");
       Method[] methods = cls.getDeclaredMethods();
       for (Method method : methods) {
         if (expectedMethods.contains(method.getName())) {
           // Parameter[] parameters = method.getParameters();
           output.add(String.format("  %-20s %s ",method.getName(),method.toGenericString() + " " + Arrays.toString(method.getParameters())));
           expectedMethods.remove(method.getName());
         }
         else {
           output.add(String.format("  %-20s *** unexpected method *** %s",method.getName(),method.toGenericString() + " " + Arrays.toString(method.getParameters())));
         }
       }
       for (String expectedMethod : expectedMethods) {
          output.add(String.format("  %-20s *** missing method ***",expectedMethod));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("java.lang.",""));         
   }
   
   
   
} 