import java.lang.reflect.*; 
import java.util.*; 

public class CollatzTester {
   public static void main(String[] args) {
       // expected Instance Variables and Mehtods
       ArrayList<String> expectedInstanceVars = new ArrayList<String>(
               Arrays.asList("startNum",
                             "rpmTemp2"));
       ArrayList<String> expectedMethods = new ArrayList<String>(
               Arrays.asList("maxValue",
                             "minOddValue",
                             "oddValues",
                             "sequence",
                             "steps",
                             "sumValues",
                             "toString"));         
        
       // Instance Variable Declarations
       ArrayList<String> output = new ArrayList<String>();
       System.out.println("Checking instance variables");
       Field[] instanceVars = Collatz.class.getDeclaredFields();
       for (Field instanceVar : instanceVars) {
         if (expectedInstanceVars.contains(instanceVar.getName())) {
           output.add(String.format("  %-20s %s ",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
           expectedInstanceVars.remove(instanceVar.getName());
         } else {
           output.add(String.format("  %-20s %s *** unexpected instance variable ***",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
         }
       }
       for (String expectedInstanceVar : expectedInstanceVars) {
          output.add(String.format("  %-20s *** missing instance variable ***",expectedInstanceVar));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("class java.lang.",""));
          
       // Contructor Declarations
       output = new ArrayList<String>();
       System.out.println("\nChecking constructors");
       Constructor[] constructors = Collatz.class.getConstructors();
       for (Constructor constructor : constructors) {
          output.add(String.format("  %-20s %s ",constructor.toGenericString(), Arrays.toString(constructor.getParameters())));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("java.lang.",""));
          
       // Method Declarations
       output = new ArrayList<String>();
       System.out.println("\nChecking methods");
       Method[] methods = Collatz.class.getDeclaredMethods();
       for (Method method : methods) {
         if (expectedMethods.contains(method.getName())) {
           // Parameter[] parameters = method.getParameters();
           output.add(String.format("  %-20s %s ",method.getName(),method.toGenericString() + " " + Arrays.toString(method.getParameters())));
           expectedMethods.remove(method.getName());
         }
         else {
           output.add(String.format("  %-20s *** unexpected method *** %s",method.getName(),method.toGenericString() + " " + Arrays.toString(method.getParameters())));
         
         }
       }
       for (String expectedMethod : expectedMethods) {
          output.add(String.format("  %-20s *** missing method ***",expectedMethod));
       }
       Collections.sort(output);
       for (String line : output) 
          System.out.println(line.replace("java.lang.",""));   
          
      System.out.println("\nVerifying Methods");
      Collatz collatzObj = new Collatz(10);
      System.out.println("  steps(10) = " + collatzObj.steps());
  
      collatzObj = new Collatz(11);
      System.out.println("  maxValue() for Collatz(11) = " + collatzObj.maxValue());
      
      collatzObj = new Collatz(27);
      System.out.println("  minOddValue() for Collatz(27) = " + collatzObj.minOddValue()); 
      
      collatzObj = new Collatz(12);
      System.out.println("  oddValues() for Collatz(12) = " + Arrays.toString(collatzObj.oddValues()));     

      collatzObj = new Collatz(27);
      System.out.println("  sumValues() for Collatz(27) = " + collatzObj.sumValues());

      System.out.println("\nVerifying Object");
      collatzObj = new Collatz(5);
      System.out.println("  Collatz(5) = " + collatzObj.toString());
      
      collatzObj = new Collatz(27);
      System.out.println("  Collatz(27) = " + collatzObj.toString());      
 
   }
   
} 