# programs
pythonIde = r'C:/Users/YourUserName/AppData/Local/Programs/Python/Python312/Lib/idlelib/idle.pyw'
javaIde = r'C:/Program Files (x86)/jGRASP/bin/jgrasp.exe'      
textEditor = r'C:/Program Files/Notepad++/notepad++.exe'
diffPgm = r'C:/Program Files/WinMerge/WinMergeU.exe'

# directories
rootDir = r'C:/Users/YourUserName/Downloads/demo'
scoreboardDir = r'C:/Users/YourUserName/Downloads/demo/scoreboard_for_demo'

# java and python class periods
classPeriodNames = ["P1","P4","P5"]      # list of class names
classPeriodNamesForMenu = ["1","4","5"]  # list of class names (shortened to make them easier to pick from the menu)

classAssignmentGroups = {}
classAssignmentGroups["P1"] = ["first6weeksAssignments"]  # list of java assignment groups for class P1
classAssignmentGroups["P4"] = ["pythonAssignments"]       # list of python assignment groups for class P4
classAssignmentGroups["P5"] = ["first6weeksAssignments"]  # list of java assignment groups for class P5

# email (email login is in login.py)
emailSignature = "/nMs. Teacher/n"
emailAttachmentDir = r"C:/Users/YourUserName/Downloads/demo/emailAttachmentDir"
# if set to False all sent email will end up in the Outlook 'Sent Items' folder
# Set to True only if you have created the folder 'CSAC' inside your 'Sent Items' folder (CSAC will then put all emails it sends into the CSAC folder)
emailUseClassPeriodSentFolders = False  

# timeout (default time in seconds for student assignment to time out - protects against endless loops
TIMEOUT_DEFAULT = 5

# days not to count for assignment's days late calculation
schoolHolidays = []
schoolHolidays.append('2024-09-02')           # Holiday
schoolHolidays.append('2024-10-03')           # PD Day
schoolHolidays.append('2024-10-04')           # PLED Day
schoolHolidays.append('2024-10-14')           # PD Day
schoolHolidays.append('2024-11-01')           # Holiday
schoolHolidays.append('2024-11-05')           # PD Day
for i in range(25, 29+1):                     # Thanksgiving Week (+1 since range function goes up to but not including last one)
    schoolHolidays.append(f'2024-11-{i:02}')  # Thanksgiving Week
for i in range(23, 31+1):                     # ChristmasBreak
    schoolHolidays.append(f'2024-12-{i:02}')  # ChristmasBreak
for i in range(1, 3+1):                       # ChristmasBreak
    schoolHolidays.append(f'2024-01-{i:02}')  # ChristmasBreak
schoolHolidays.append('2024-01-06')           # PD Day
schoolHolidays.append('2024-01-20')           # Holiday
schoolHolidays.append('2024-01-29')           # PD Day
schoolHolidays.append('2024-02-17')           # PD Day
schoolHolidays.append('2024-03-14')           # PLED Day
for i in range(17, 21+1):                     # Spring Break Week
    schoolHolidays.append(f'2024-03-{i:02}')  # Spring Break Week
schoolHolidays.append('2024-03-31')           # Holiday
schoolHolidays.append('2024-04-18')           # PD Day
schoolHolidays.append('2024-05-26')           # Holiday
schoolHolidays.append('2024-05-30')           # PD Day