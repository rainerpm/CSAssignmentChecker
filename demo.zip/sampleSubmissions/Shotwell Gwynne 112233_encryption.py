def encrypt(line):
      new = ""
      thing = ""
      realnew = ""
      for char in line:
        char = int(char)
        char = (char + 7) % 10
        new = new + str(char)
      for k in range(0, len(new), 4):
        thing = thing + new[k] + new[k + 1] + new[k + 2] + new[k + 3]
        for j in range(len(thing)):
          thing2 = ""
          thing2 = thing2 + thing[2]
          thing2 = thing2 + thing[3]
          thing2 = thing2 + thing[1]  # ERROR - should be thing[0]
          thing2 = thing2 + thing[1]
        realnew = realnew + thing2
        thing2 = ""
        thing = ""
      return realnew

fh = open("encryption.dat")
number = fh.readline()
number = int(number.strip())
for i in range(number):
  line = fh.readline()
  line = line.strip()
  print(encrypt(line))
