fh = open("encryption.dat")
num = fh.readline()
num = num.strip()

for i in range(int(num)):
  line = fh.readline()
  line = line.strip()
  new = ""
  thing = ""
  realnew = ""
  for char in line:
    char = int(char)
    char = (char + 7) % 10
    new = new + str(char)
  for k in range(0, len(new), 4):
    thing = thing + new[k] + new[k + 1] + new[k + 2] + new[k + 3]
    for j in range(len(thing)):
      thing2 = ""
      thing2 = thing2 + thing[2]
      thing2 = thing2 + thing[3]
      thing2 = thing2 + thing[1]  # ERROR - should be thing[0]
      thing2 = thing2 + thing[1]
    realnew = realnew + thing2
    thing2 = ""
    thing = ""
  print(realnew)
