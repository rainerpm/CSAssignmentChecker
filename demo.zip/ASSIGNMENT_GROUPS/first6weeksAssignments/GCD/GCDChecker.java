/* Code to check the contents of the student's program (number and type of instance variables as well as details 
   on the constructors and methods in the student's program). The output is compared to checker.txt file provided 
   by the teacher.
   
   TO USE
   This file can be used as is to check any program by changing the EDIT liens below to make it specific to that program. 
*/

import java.lang.reflect.*; 
import java.util.*; 

public class GCDChecker {     // EDIT CLASS NAME

   public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException,InvocationTargetException {
      // Determine if the constructor required by the below code actually exists 
      String className = "GCD";   // EDIT CLASS NAME
      String requiredConstructor = "public GCD()"; // EDIT CONSTRUCTOR NAME & PARAMETERS TYPES (the constructor used below for reflection) - e.g. java.lang.String, int
      Constructor reqConstructor = searchForRequiredConstructor(className,requiredConstructor,false);
      boolean foundRequiredConstructor = (reqConstructor != null);
      if (!foundRequiredConstructor) { 
         System.out.println("Checker did NOT find the required constructor: " + requiredConstructor);
         System.out.println("Only found these constructors");
         searchForRequiredConstructor(className,requiredConstructor,true);         
      }
      else {
         System.out.println("*** CHECKING GCD class ***");  // EDIT CLASS NAME
         // Class that we are testing using reflection
         GCD studentClass = (GCD) reqConstructor.newInstance();    // EDIT CLASS NAME AND PROVIDE EXAMPLE CONSTRUCTOR PARAMETERS
         Class reflectedClass = studentClass.getClass();
      
        // *** Test the structure of the program ***
         ArrayList<String> expectedInstanceVars = new ArrayList<String>(   // EDIT EXPECTED INSTANCE VARIABLES
              Arrays.asList("numerator",
                            "denominator"
                            ));
         ArrayList<String> expectedMethods = new ArrayList<String>(        // EDIT EXPECTED METHODS
              Arrays.asList("getNumerator",
                            "setNumerator",
                            "getDenominator",
                            "setDenominator",
                            "calcGCD",
                            "denominatorSimplified",
                            "numeratorSimplified",
                            "toString"));
                               
         // check the instance variables (make sure to put correct class name before .class below)
         checkInstanceVariables(expectedInstanceVars,reflectedClass);
         // check the instance variables (make sure to put correct class name before .class below)
         checkConstructors(reflectedClass, true);
         // check the methods (make sure to put correct class name before .class below)
         checkMethods(expectedMethods,reflectedClass, true);  
      }         
   }
   
   
   ////////////////////////////////////////////////////////////////////////////////////
   // program checking methods (shouldn't need to change)
   ////////////////////////////////////////////////////////////////////////////////////
   public static Constructor searchForRequiredConstructor(String className,String requiredConstructor, boolean printConstructors) throws ClassNotFoundException {
      Class cls = Class.forName(className);
      Constructor[] allConstructors = cls.getDeclaredConstructors();
      boolean requiredConstructorFound = false;
      Constructor required = null;
      for (Constructor ctor : allConstructors) { 
         Class[] pType  = ctor.getParameterTypes(); 
         if (printConstructors) {
            System.out.println("  " + ctor.toGenericString());
         }     
         if (ctor.toGenericString().equals(requiredConstructor)) {
            requiredConstructorFound = true;  
            required = ctor;
         }
      } 
      return required;
   }
   
   
   public static void checkInstanceVariables(ArrayList<String> expectedInstanceVars, Class cls) {
      ArrayList<String> output = new ArrayList<String>();
      System.out.println("Checking instance variables");
      Field[] instanceVars = cls.getDeclaredFields();
      for (Field instanceVar : instanceVars) {
         if (expectedInstanceVars.contains(instanceVar.getName())) {
            output.add(String.format("  %-20s %s ",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
            expectedInstanceVars.remove(instanceVar.getName());
         } else {
            output.add(String.format("  %-20s %s *** unexpected instance variable ***",instanceVar.getName(), Modifier.toString(instanceVar.getModifiers()) + " " + instanceVar.getType() ));
         }
      }
      for (String expectedInstanceVar : expectedInstanceVars) {
         output.add(String.format("  %-20s *** missing instance variable ***",expectedInstanceVar));
      }
      Collections.sort(output);
      for (String line : output) 
         System.out.println(line.replace("class java.lang.",""));
   }
    
   public static void checkConstructors(Class cls, boolean parameterNames) {
      ArrayList<String> output = new ArrayList<String>();
      System.out.println("\nChecking constructors");
      Constructor[] constructors = cls.getConstructors();
      for (Constructor constructor : constructors) {
         if (parameterNames)
            output.add(String.format("  %-20s",constructor.toGenericString()));
         else 
            output.add(String.format("  %-20s ",constructor.toGenericString()));          
      }
      Collections.sort(output);
      for (String line : output) 
         System.out.println(line.replace("java.lang.",""));
   }
   
   public static ArrayList<String> checkMethods(ArrayList<String> expectedMethods, Class cls, boolean parameterNames) {
      ArrayList<String> output = new ArrayList<String>();
      ArrayList<String> inExpectedMethods = new ArrayList<String>();
   
      System.out.println("\nChecking methods");
      Method[] methods = cls.getDeclaredMethods();
      for (Method method : methods) {
         if (expectedMethods.contains(method.getName())) {
            inExpectedMethods.add(method.getName());
            if (parameterNames) {
               output.add(String.format("  %-20s %s ",method.getName(),method.toGenericString()));
            }
            else {
               output.add(String.format("  %-20s %s ",method.getName(),method.toGenericString()));
            }
            expectedMethods.remove(method.getName());
         }
         else {
            output.add(String.format("  %-20s *** unexpected method *** %s",method.getName(),method.toGenericString()));
         }
      }
      for (String expectedMethod : expectedMethods) {
         output.add(String.format("  %-20s *** missing method ***",expectedMethod));
      }
      Collections.sort(output);
      for (String line : output) 
         System.out.println(line.replace("java.lang.",""));  
         
      return inExpectedMethods;              
   }
   
   public static Object runMethod(Object obj, ArrayList<String> validMethods, String methodName, Class[] parameters, Object[] arguments) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
   {
      if (validMethods.contains(methodName)) {
         Method method = obj.getClass().getMethod(methodName, parameters);
         Object result = method.invoke(obj,arguments);  
         return result;      
      }
      else {
         System.out.println("    " + methodName + " was not implemented.");
         return null;
      }
   }

}
