def encrypt(line):
  new = ""
  seq = ""
  encrypted = ""
  for char in line:
    char = int(char)
    char = (char + 7) % 10
    new = new + str(char)
  for k in range(0, len(new), 4):
    seq = seq + new[k] + new[k + 1] + new[k + 2] + new[k + 3]
    for j in range(len(seq)):
      seq2 = ""
      seq2 = seq2 + seq[2]
      seq2 = seq2 + seq[3]
      seq2 = seq2 + seq[0]
      seq2 = seq2 + seq[1]
    encrypted = encrypted + seq2
    seq2 = ""
    seq = ""
  return encrypted

fh = open("encryption.dat")
n = fh.readline()
n = n.strip()
for i in range(int(n)):
  line = fh.readline()
  line = line.strip()
  msg = encrypt(line)
  print(msg)
